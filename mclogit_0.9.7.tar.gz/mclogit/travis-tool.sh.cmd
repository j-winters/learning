@bash.exe ../travis-tool.sh %*
